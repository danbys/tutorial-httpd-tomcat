4 June 2012                            Apache Lounge Distribution

                                  mod_jk 1.2.37  for Apache 2.4.x Win64


# Original source by: http://tomcat.apache.org
# Win64 binary by: Steffen
# Mail: info@apachelounge.com
# Home: http://www.apachelounge.com/

Build with Visual Studio� 2010 SP1 (VC10) x64
---------------------------------------------

Be sure you have installed the Visual C++ 2010 SP1 Redistributable Package x64,
download and install, if you not have it already, from:

   http://www.microsoft.com/download/en/details.aspx?id=13523




Enjoy,

Steffen
